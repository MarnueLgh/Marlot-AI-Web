---
name: cleo-hartmann
description: "Cleo Hartmann is a warm, stylish young European woman with a modern casual aesthetic. She has shoulder-length platinum blonde hair with visible dark roots, soft wavy texture, and a center part. Her face is oval-shaped with dewy skin, light freckles across her nose and cheeks, glossy nude lips, and a small gold nose ring. Her eyes are large and expressive, a striking light blue-gray, complemented by thick natural brows and long lashes. She typically wears simple but fashionable layering outfits in warm tones like red, camel, and cream, paired with gray basics. Her accessories include a small gold hoop earring and a black chain-strap bag. Standing around 5’7” with a slim build, she has a relaxed and confident presence, often captured in candid editorial-style shots with soft diffused lighting and a shallow depth of field."
---

# CHARACTER RULES — [Cleo Hartmann]

## FÍSICO GENERAL
- Edad aparente: 25–27 años
- Complexión: delgada / slim, sin ser atlética
- Estatura: 170 cm aprox (5'7")
- Silueta: hombros medianos, cadera ligera, cuello largo

## ROSTRO
- Forma: ovalada, pómulos suaves
- Piel: tono medio-claro, dewy, ligeras pecas en nariz y mejillas
- Ojos: azul-gris claro, almendrados, pestañas largas naturales
- Cejas: gruesas, naturales, ligeramente brushed-up
- Labios: medianos, nude/glossy, ligeramente carnosos
- Nariz: pequeña, con argolla dorada fina
- Aretes: hoop dorado pequeño, una sola pieza

## CABELLO
- Largo: hasta los hombros (shoulder-length)
- Color: rubio platino con raíces oscuras visibles (dark roots)
- Textura: lacio con ligeras ondas naturales, sin peinar formalmente
- Partido: al centro o ligeramente de lado

## ESTILO / ROPA
- Vibe: casual europeo, layering, prendas oversized
- Paleta: tonos cálidos (rojo, camel, crema) + básicos grises
- Accesorios: joyería dorada minimalista, bolsas con cadena

## FOTOGRAFÍA (consistencia técnica)
- Siempre: medium format look, shallow depth of field
- Fondo base: muted dusty blue o warm beige
- Iluminación: soft diffused, sin flash duro
- Estilo: editorial candid, no posado artificial

---

## PROMPTS CON ÁNGULOS DEL PERSONAJE

[BASE] Young European woman, mid-20s, oval face, sharp natural brows, 
light blue-gray eyes, small nose ring, small gold hoop earring, 
dewy glowy skin with light freckles, glossy nude lips, 
shoulder-length blonde hair with visible dark roots, 
slightly wavy and tousled, thin and lean build.

[BASE] Left side profile portrait, face and upper body visible, 
head turned 90 degrees left, sharp jawline and side profile visible, 
hair falling naturally to the side. 
Wearing red knit sweater over gray t-shirt. 
Muted blue studio backdrop, soft side lighting, 
medium format film, shallow depth of field. --ar 3:4 --style raw --v 7

[BASE] Right side profile portrait, face and upper body visible, 
head turned 90 degrees right, gold hoop earring visible, 
nose ring in profile, hair tucked behind ear. 
Wearing red knit sweater over gray t-shirt. 
Muted blue studio backdrop, soft diffused lighting, 
medium format film, shallow depth of field. --ar 3:4 --style raw --v 7

[BASE] Back view portrait, subject facing away from camera, 
shoulder-length blonde hair with dark roots visible from behind, 
slight head turn showing left cheekbone and jawline. 
Wearing red knit sweater. 
Muted blue studio backdrop, even soft lighting. 
--ar 3:4 --style raw --v 7

[BASE] Three-quarter aerial angle portrait, camera slightly above eye level, 
face angled upward toward lens, hair parting visible from above. 
Wearing red knit sweater. Muted blue studio backdrop, 
top-down soft diffused studio lighting. 
--ar 1:1 --style raw --v 7

[BASE] Full body studio portrait, subject standing relaxed, 
slight weight on one hip, arms loosely at sides. 
Wearing red oversized knit sweater layered over gray t-shirt, 
black chain-strap bag on shoulder, straight-leg jeans or 
dark trousers, minimal shoes. 
Muted blue seamless studio backdrop, wooden studio floor, 
soft even lighting. Vertical frame. 
--ar 2:3 --style raw --v 7